# 📡 CryptoSignal — TradingView → Telegram Bot + Dashboard

A beginner-friendly, production-ready full-stack crypto trading signal app.

**What it does:**
- Receives TradingView webhook alerts
- Forwards signals to a Telegram chat/channel instantly
- Shows all signals on a live dashboard (auto-refreshes every 5 s)
- One-click deploy to Railway (free tier)

---

## 🗂 Folder Structure

```
crypto_signals/
├── app.py                  ← Flask backend (all routes + logic)
├── requirements.txt        ← Python dependencies
├── Procfile                ← Gunicorn start command (Railway/Heroku)
├── runtime.txt             ← Python version pin
├── railway.toml            ← Railway deploy config
├── .env.example            ← Environment variable template
├── .gitignore
├── README.md
├── templates/
│   └── index.html          ← Dashboard HTML
└── static/
    ├── css/
    │   └── style.css       ← Dark-mode responsive stylesheet
    └── js/
        └── app.js          ← Polling + dynamic card rendering
```

---

## 🚀 Quick Start (Local)

### 1. Clone & install

```bash
cd crypto_signals
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Set environment variables

```bash
cp .env.example .env
# Edit .env with your values
```

### 3. Run

```bash
python app.py
# or with gunicorn:
gunicorn app:app --bind 0.0.0.0:5000
```

Open [http://localhost:5000](http://localhost:5000) — the dashboard will load.

---

## 🤖 Telegram Setup

1. Message **@BotFather** on Telegram → `/newbot` → follow prompts.
2. Copy the **bot token** → paste into `TELEGRAM_BOT_TOKEN`.
3. Message **@userinfobot** to get your numeric user ID → paste into `TELEGRAM_CHAT_ID`.
4. Start a conversation with your bot (send `/start`) so it can message you.

> **Groups/Channels:** invite the bot, make it admin, and use the group/channel ID (e.g. `-1001234567890`).

---

## 🌐 Deploy to Railway (Free)

1. Push this folder to a GitHub repository.
2. Go to [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub repo**.
3. Select your repo.
4. In **Variables**, add:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID`
5. Railway auto-detects `Procfile` and deploys. You get a public HTTPS URL.

---

## ⚡ Connect TradingView

1. Open any chart → click **Alerts** (clock icon) → **Create Alert**.
2. Under **Notifications** → enable **Webhook URL**.
3. Paste your Railway URL + `/webhook`:
   ```
   https://your-app.up.railway.app/webhook
   ```
4. Set the **Message** field to:
   ```json
   {
     "action":    "{{strategy.order.action}}",
     "symbol":    "{{ticker}}",
     "price":     "{{close}}",
     "timeframe": "{{interval}}",
     "message":   "Alert fired"
   }
   ```
5. Save — signals will appear on your dashboard and in Telegram instantly!

---

## 🛣 API Reference

| Method | Route           | Description                          |
|--------|-----------------|--------------------------------------|
| GET    | `/`             | Dashboard                            |
| POST   | `/webhook`      | Receive TradingView alert            |
| GET    | `/api/signals`  | Latest signals JSON (`?limit=N`)     |
| GET    | `/api/stats`    | Total / buy / sell counts            |
| POST   | `/test-signal`  | Inject a random fake signal          |
| GET    | `/health`       | Health check                         |

### Webhook payload fields

| Field       | Required | Example              |
|-------------|----------|----------------------|
| `action`    | ✅        | `"BUY"` / `"SELL"`  |
| `symbol`    | ✅        | `"BTCUSDT"`          |
| `price`     | ✅        | `"65000"`            |
| `timeframe` | ❌        | `"1H"`               |
| `message`   | ❌        | `"RSI oversold"`     |

### Optional security header

Add `WEBHOOK_SECRET=your_secret` in env vars, then set the header in TradingView:

```
X-Webhook-Secret: your_secret
```

---

## 🔧 Environment Variables

| Variable             | Required | Description                          |
|----------------------|----------|--------------------------------------|
| `TELEGRAM_BOT_TOKEN` | ✅        | From @BotFather                      |
| `TELEGRAM_CHAT_ID`   | ✅        | Your user ID or group/channel ID     |
| `WEBHOOK_SECRET`     | ❌        | Optional extra security token        |
| `PORT`               | ❌        | Set automatically by Railway         |

---

## 📝 Notes

- Signals are stored **in memory** — they reset on restart. For persistence, swap the `deque` in `app.py` for SQLite with `flask-sqlalchemy`.
- The app uses **2 Gunicorn workers** — both share the in-memory deque only if running on a single dyno. For multi-instance deployments, use Redis or a database.
- The `/test-signal` endpoint is great for testing your Telegram integration before going live.

---

Made with ❤️ — Flask + Telegram + TradingView
