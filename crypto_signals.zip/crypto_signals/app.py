"""
Crypto Trading Signal Web App
Flask backend with TradingView webhook + Telegram bot integration
"""

import os
import json
import requests
from datetime import datetime
from flask import Flask, request, jsonify, render_template
from collections import deque

app = Flask(__name__)

# ─── Config ────────────────────────────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID   = os.environ.get("TELEGRAM_CHAT_ID", "")
WEBHOOK_SECRET     = os.environ.get("WEBHOOK_SECRET", "")   # optional extra security
MAX_SIGNALS        = 100   # keep last 100 signals in memory

# ─── In-memory signal store ─────────────────────────────────────────────────────
signals: deque = deque(maxlen=MAX_SIGNALS)

# ─── Telegram helper ────────────────────────────────────────────────────────────
def send_telegram(message: str) -> bool:
    """Send a message to the configured Telegram chat."""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        app.logger.warning("Telegram credentials not configured – skipping send.")
        return False
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "HTML",
    }
    try:
        resp = requests.post(url, json=payload, timeout=10)
        resp.raise_for_status()
        return True
    except requests.RequestException as e:
        app.logger.error(f"Telegram send failed: {e}")
        return False


def format_telegram_message(signal: dict) -> str:
    """Format a signal dict into a nice Telegram HTML message."""
    emoji = "🟢" if signal.get("action", "").upper() == "BUY" else "🔴"
    action = signal.get("action", "N/A").upper()
    symbol = signal.get("symbol", "N/A").upper()
    price  = signal.get("price", "N/A")
    tf     = signal.get("timeframe", "N/A")
    msg    = signal.get("message", "")
    ts     = signal.get("timestamp", "")

    lines = [
        f"{emoji} <b>TRADING SIGNAL</b> {emoji}",
        f"",
        f"<b>Action:</b>    {action}",
        f"<b>Symbol:</b>    {symbol}",
        f"<b>Price:</b>     {price}",
        f"<b>Timeframe:</b> {tf}",
    ]
    if msg:
        lines.append(f"<b>Note:</b>      {msg}")
    if ts:
        lines.append(f"<b>Time:</b>      {ts}")
    lines.append("\n<i>Powered by CryptoSignal Bot 🤖</i>")
    return "\n".join(lines)


# ─── Routes ─────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    """Serve the dashboard."""
    return render_template("index.html")


@app.route("/webhook", methods=["POST"])
def webhook():
    """
    TradingView alert endpoint.
    Accepts JSON body with any of:
      { "action": "BUY|SELL", "symbol": "BTCUSDT", "price": "65000",
        "timeframe": "1H", "message": "RSI oversold" }
    Optional header  X-Webhook-Secret  for extra security.
    """
    # ── optional secret check ──────────────────────────────────────────────────
    if WEBHOOK_SECRET:
        provided = request.headers.get("X-Webhook-Secret", "")
        if provided != WEBHOOK_SECRET:
            return jsonify({"error": "Unauthorized"}), 401

    # ── parse body ─────────────────────────────────────────────────────────────
    data = {}
    if request.is_json:
        data = request.get_json(silent=True) or {}
    else:
        # TradingView sometimes sends plain text; try to decode
        raw = request.data.decode("utf-8", errors="ignore").strip()
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            # treat the whole body as a "message" field
            data = {"message": raw}

    # ── build signal ───────────────────────────────────────────────────────────
    signal = {
        "action":    data.get("action", "SIGNAL").upper(),
        "symbol":    data.get("symbol", "UNKNOWN").upper(),
        "price":     str(data.get("price", "N/A")),
        "timeframe": data.get("timeframe", "N/A"),
        "message":   data.get("message", ""),
        "timestamp": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
        "raw":       data,
    }

    # ── store ──────────────────────────────────────────────────────────────────
    signals.appendleft(signal)   # newest first

    # ── notify Telegram ────────────────────────────────────────────────────────
    tg_ok = send_telegram(format_telegram_message(signal))

    return jsonify({
        "status":   "ok",
        "signal":   signal,
        "telegram": tg_ok,
    }), 200


@app.route("/api/signals")
def api_signals():
    """Return the latest signals as JSON (polled by the dashboard)."""
    limit = min(int(request.args.get("limit", 20)), MAX_SIGNALS)
    return jsonify(list(signals)[:limit])


@app.route("/api/stats")
def api_stats():
    """Return simple statistics for the dashboard header."""
    all_sigs = list(signals)
    buys  = sum(1 for s in all_sigs if s["action"] == "BUY")
    sells = sum(1 for s in all_sigs if s["action"] == "SELL")
    return jsonify({
        "total": len(all_sigs),
        "buys":  buys,
        "sells": sells,
    })


@app.route("/health")
def health():
    """Railway / uptime-robot health check."""
    return jsonify({"status": "healthy", "signals_stored": len(signals)}), 200


@app.route("/test-signal", methods=["POST"])
def test_signal():
    """
    Dev helper – inject a fake signal without calling TradingView.
    POST /test-signal   (no body needed; uses defaults)
    """
    import random
    fake = {
        "action":    random.choice(["BUY", "SELL"]),
        "symbol":    random.choice(["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT"]),
        "price":     str(round(random.uniform(100, 70000), 2)),
        "timeframe": random.choice(["5m", "15m", "1H", "4H", "1D"]),
        "message":   random.choice(["RSI oversold", "MACD crossover", "EMA breakout", "Volume spike"]),
    }
    # reuse the webhook logic
    with app.test_request_context(
        "/webhook",
        method="POST",
        json=fake,
        content_type="application/json",
    ):
        # directly call business logic instead of HTTP round-trip
        signal = {**fake, "timestamp": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"), "raw": fake}
        signal["action"] = signal["action"].upper()
        signal["symbol"] = signal["symbol"].upper()
        signals.appendleft(signal)
        tg_ok = send_telegram(format_telegram_message(signal))

    return jsonify({"status": "ok", "signal": signal, "telegram": tg_ok}), 200


# ─── Entry point ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
