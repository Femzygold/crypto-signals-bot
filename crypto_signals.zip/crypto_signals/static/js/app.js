/**
 * CryptoSignal Dashboard — frontend JS
 * Polls /api/signals every 5 s and updates the UI without a page reload.
 */

(function () {
  "use strict";

  /* ── Config ─────────────────────────────────────────────────── */
  const POLL_INTERVAL = 5000; // ms
  const MAX_CARDS     = 50;

  /* ── State ──────────────────────────────────────────────────── */
  let lastSignalTime = null;
  let pollTimer      = null;

  /* ── DOM refs ───────────────────────────────────────────────── */
  const signalList   = document.getElementById("signal-list");
  const emptyState   = document.getElementById("empty-state");
  const statTotal    = document.getElementById("stat-total");
  const statBuys     = document.getElementById("stat-buys");
  const statSells    = document.getElementById("stat-sells");
  const statusDot    = document.getElementById("status-dot");
  const lastUpdateEl = document.getElementById("last-update");
  const webhookDisp  = document.getElementById("webhook-display");
  const webhookCode  = document.getElementById("webhook-code");
  const btnRefresh   = document.getElementById("btn-refresh");
  const btnTest      = document.getElementById("btn-test");
  const btnCopy      = document.getElementById("btn-copy");
  const toast        = document.getElementById("toast");
  const tpl          = document.getElementById("tpl-signal");

  /* ── Webhook URL ─────────────────────────────────────────────── */
  function setWebhookUrl() {
    const url = `${location.origin}/webhook`;
    if (webhookDisp) webhookDisp.textContent = url;
    if (webhookCode) webhookCode.textContent  = url;
  }
  setWebhookUrl();

  /* ── Toast helper ────────────────────────────────────────────── */
  let toastTimer;
  function showToast(msg, duration = 2800) {
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), duration);
  }

  /* ── Status dot ──────────────────────────────────────────────── */
  function setStatus(ok) {
    statusDot.classList.toggle("ok",    ok);
    statusDot.classList.toggle("error", !ok);
  }

  /* ── Time formatting ─────────────────────────────────────────── */
  function timeAgo(tsStr) {
    if (!tsStr) return "";
    // tsStr example: "2024-05-10 14:32:01 UTC"
    const ms = new Date(tsStr.replace(" UTC", "Z")).getTime();
    if (isNaN(ms)) return tsStr;
    const diff = Math.floor((Date.now() - ms) / 1000);
    if (diff < 5)   return "just now";
    if (diff < 60)  return `${diff}s ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    return `${Math.floor(diff / 3600)}h ago`;
  }

  /* ── Build a signal card ─────────────────────────────────────── */
  function buildCard(signal) {
    const node   = tpl.content.cloneNode(true);
    const card   = node.querySelector(".signal-card");
    const badge  = node.querySelector(".signal-badge");
    const sym    = node.querySelector(".signal-symbol");
    const price  = node.querySelector(".signal-price");
    const tf     = node.querySelector(".signal-tf");
    const msg    = node.querySelector(".signal-msg");
    const time   = node.querySelector(".signal-time");

    const action = (signal.action || "SIGNAL").toUpperCase();

    card.classList.add(action === "BUY" ? "buy-card" : action === "SELL" ? "sell-card" : "");
    badge.textContent  = action;
    badge.className    = `signal-badge ${action}`;
    sym.textContent    = signal.symbol  || "–";
    price.textContent  = signal.price !== "N/A" ? `$${Number(signal.price).toLocaleString()}` : "";
    tf.textContent     = signal.timeframe || "";
    msg.textContent    = signal.message   || "";
    time.textContent   = signal.timestamp ? timeAgo(signal.timestamp) : "";

    // store timestamp for auto-refresh of "time ago"
    if (signal.timestamp) card.dataset.ts = signal.timestamp;

    return node;
  }

  /* ── Render all signals ──────────────────────────────────────── */
  function renderSignals(data) {
    if (!data || data.length === 0) {
      signalList.innerHTML = "";
      signalList.appendChild(emptyState || createEmptyState());
      return;
    }

    // Remove empty state if present
    const existingEmpty = signalList.querySelector(".empty-state");
    if (existingEmpty) existingEmpty.remove();

    // Check if newest signal changed
    const newestTs = data[0]?.timestamp;
    const isNew    = newestTs && newestTs !== lastSignalTime;
    if (isNew) lastSignalTime = newestTs;

    // Full re-render (simple; list is capped at 50)
    signalList.innerHTML = "";
    const frag = document.createDocumentFragment();
    data.slice(0, MAX_CARDS).forEach((sig) => frag.appendChild(buildCard(sig)));
    signalList.appendChild(frag);

    if (isNew) showToast(`📡 New signal: ${data[0].action} ${data[0].symbol}`);
  }

  /* ── Fetch signals ───────────────────────────────────────────── */
  async function fetchSignals() {
    try {
      const res  = await fetch("/api/signals?limit=50");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setStatus(true);
      renderSignals(data);
    } catch (err) {
      setStatus(false);
      console.error("fetchSignals:", err);
    }
    lastUpdateEl.textContent = `Updated ${new Date().toLocaleTimeString()}`;
  }

  /* ── Fetch stats ─────────────────────────────────────────────── */
  async function fetchStats() {
    try {
      const res  = await fetch("/api/stats");
      if (!res.ok) return;
      const data = await res.json();
      statTotal.textContent = data.total ?? "–";
      statBuys.textContent  = data.buys  ?? "–";
      statSells.textContent = data.sells ?? "–";
    } catch (_) {}
  }

  /* ── Auto refresh "time ago" labels every 30 s ───────────────── */
  function refreshTimestamps() {
    signalList.querySelectorAll(".signal-card[data-ts]").forEach((card) => {
      const time = card.querySelector(".signal-time");
      if (time) time.textContent = timeAgo(card.dataset.ts);
    });
  }

  /* ── Poll loop ───────────────────────────────────────────────── */
  async function poll() {
    await fetchSignals();
    await fetchStats();
    pollTimer = setTimeout(poll, POLL_INTERVAL);
  }

  /* ── Button: manual refresh ──────────────────────────────────── */
  btnRefresh.addEventListener("click", async () => {
    clearTimeout(pollTimer);
    btnRefresh.textContent = "↺ Refreshing…";
    btnRefresh.disabled    = true;
    await fetchSignals();
    await fetchStats();
    btnRefresh.textContent = "↺ Refresh";
    btnRefresh.disabled    = false;
    pollTimer = setTimeout(poll, POLL_INTERVAL);
  });

  /* ── Button: inject test signal ─────────────────────────────── */
  btnTest.addEventListener("click", async () => {
    btnTest.disabled    = true;
    btnTest.textContent = "🧪 Sending…";
    try {
      const res = await fetch("/test-signal", { method: "POST" });
      if (!res.ok) throw new Error("Server error");
      const data = await res.json();
      showToast(`✅ Test signal sent: ${data.signal?.action} ${data.signal?.symbol}`);
      await fetchSignals();
      await fetchStats();
    } catch (err) {
      showToast("❌ Failed to send test signal");
      console.error(err);
    }
    btnTest.disabled    = false;
    btnTest.textContent = "🧪 Test Signal";
  });

  /* ── Button: copy webhook URL ────────────────────────────────── */
  btnCopy.addEventListener("click", async () => {
    const url = `${location.origin}/webhook`;
    try {
      await navigator.clipboard.writeText(url);
      showToast("📋 Webhook URL copied!");
    } catch (_) {
      showToast("⚠️ Copy failed – please copy manually");
    }
  });

  /* ── Refresh timestamps every 30 s ──────────────────────────── */
  setInterval(refreshTimestamps, 30_000);

  /* ── Kick off ───────────────────────────────────────────────── */
  poll();
})();
